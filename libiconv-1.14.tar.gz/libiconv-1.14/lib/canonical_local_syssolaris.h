  (int)(long)&((struct stringpool_t *)0)->stringpool_str38,
  (int)(long)&((struct stringpool_t *)0)->stringpool_str515,
